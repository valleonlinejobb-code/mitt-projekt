# Trading Agents Base

Den här mappen är en lärverkstad för aktieanalys med Claude Code. Allt är experiment, inget är finansiell rådgivning.

## Regler
- Handla aldrig med riktiga pengar. Endast pappershandel (`"paper": true`).
- Lägg aldrig en order utan att användaren skriver ett tydligt ja för just den ordern.
- Be aldrig om API-nycklar i chatten och skriv aldrig ut dem. Användaren lägger dem själv i miljövariabler.
- Kronos är en statistisk modell. Presentera banor som osäkerhet, aldrig som en förutsägelse eller ett köptips.

## Innehåll
- `.claude/skills/trader-*`: 11 skills (scanner, news, entry, exit, budget, risk, timemachine, alerts, analyst, pelosi, broker). Källa: github.com/Jakeschincariol/day-trader-skill, commit 3d0f4ef (MIT).
- `kronos/`: Kronos från github.com/shiyu-coder/Kronos, commit 67b630e (MIT), samt `run_kronos.py` som ritar många möjliga kursbanor för en aktie.
- `trader/`: skillsens arbetsfiler (watchlist, planer, orderförslag). Skillsen skriver hit.
- `models/`: nedladdade Kronos-modellfiler. `output/`: bilder från Kronos.

## Så kör du
- Prognos: `run.bat AAPL --model base --days 20 --paths 30`
- Skills: starta `claude` i den här mappen så hittas trader-skillsen automatiskt.
