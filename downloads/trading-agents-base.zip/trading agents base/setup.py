"""Installerar allt som behövs för Trading Agents Base (Windows, Mac eller Linux).

Gör tre saker:
  1. skapar en egen Python-miljö i mappen .venv
  2. installerar Kronos beroenden och yfinance
  3. laddar ner Kronos-base och dess tokenizer (några hundra MB) till mappen models
"""
import argparse
import os
import subprocess
import sys
import venv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
MODELS = ROOT / "models"
REPOS = ["NeoQuasar/Kronos-Tokenizer-base", "NeoQuasar/Kronos-base"]


def venv_python() -> Path:
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def run(cmd) -> None:
    cmd = [str(c) for c in cmd]
    print("\n> " + " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True)


def main() -> None:
    ap = argparse.ArgumentParser(description="Installerar Trading Agents Base")
    ap.add_argument("--torch-index", help="Adress till PyTorch-index för NVIDIA-grafikkort (hämtas från pytorch.org)")
    ap.add_argument("--skip-install", action="store_true", help="hoppa över pip-installationen")
    ap.add_argument("--skip-models", action="store_true", help="hoppa över nedladdning av modellerna")
    a = ap.parse_args()

    v = sys.version_info
    print(f"Python {v.major}.{v.minor}.{v.micro}")
    if v < (3, 10):
        sys.exit("Python 3.10 eller nyare behövs. Installera Python 3.12 från python.org.")
    if v >= (3, 13):
        print("VARNING: Kronos fasta versioner (pandas 2.2.2) saknar troligen färdiga paket för Python 3.13 eller nyare.")
        print("         Om installationen misslyckas, installera Python 3.12 från python.org och kör igen.")

    if not VENV.exists():
        print("Skapar virtuell miljö i .venv ...")
        venv.EnvBuilder(with_pip=True).create(VENV)
    py = venv_python()
    if not py.exists():
        sys.exit("Kunde inte skapa den virtuella miljön (.venv).")

    if not a.skip_install:
        run([py, "-m", "pip", "install", "--upgrade", "pip"])
        if a.torch_index:
            run([py, "-m", "pip", "install", "torch", "--index-url", a.torch_index])
        run([py, "-m", "pip", "install", "-r", ROOT / "kronos" / "requirements.txt"])
        run([py, "-m", "pip", "install", "yfinance"])

    if not a.skip_models:
        MODELS.mkdir(exist_ok=True)
        print("\nLaddar ner Kronos-base från Hugging Face till mappen models ...", flush=True)
        env = dict(os.environ, HF_HOME=str(MODELS))
        code = "import sys; from huggingface_hub import snapshot_download as d; [print('klart:', d(r)) for r in sys.argv[1:]]"
        subprocess.run([str(py), "-c", code, *REPOS], check=True, env=env)

    print("\nKlart! Kör en prognos med:  run.bat AAPL   (på Mac/Linux: .venv/bin/python kronos/run_kronos.py AAPL)")


if __name__ == "__main__":
    main()
