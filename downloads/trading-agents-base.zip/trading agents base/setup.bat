@echo off
setlocal
cd /d "%~dp0"
set "PY="
for %%V in (3.12 3.11 3.10) do (
  if not defined PY (
    py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
  )
)
if not defined PY (
  python -c "import sys" >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo Python hittades inte. Installera Python 3.12 fran python.org och kryssa i "Add python.exe to PATH".
  pause
  exit /b 1
)
echo Anvander: %PY%
%PY% "%~dp0setup.py" %*
echo.
pause
