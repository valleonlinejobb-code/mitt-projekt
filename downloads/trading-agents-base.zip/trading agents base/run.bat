@echo off
setlocal
set "HF_HOME=%~dp0models"
if not exist "%~dp0.venv\Scripts\python.exe" (
  echo Kor setup.bat forst.
  pause
  exit /b 1
)
if not exist "%~dp0output" mkdir "%~dp0output"
pushd "%~dp0output"
"%~dp0.venv\Scripts\python.exe" "%~dp0kronos\run_kronos.py" %*
popd
echo.
pause
