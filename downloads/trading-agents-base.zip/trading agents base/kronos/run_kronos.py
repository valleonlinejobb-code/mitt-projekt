"""Kör Kronos på en aktie och visar många möjliga framtida kursbanor.

Läggs i Kronos-mappen (där mappen "model" finns) och körs så här:
    python run_kronos.py AAPL
    python run_kronos.py TSLA --model base --days 20 --paths 50

Det här är ett experiment. Banorna är statistiska gissningar, inga köptips.
"""
import argparse
import sys

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import yfinance as yf

from model import Kronos, KronosPredictor, KronosTokenizer

MODELS = {
    # namn: (modell, tokenizer, max antal staplar modellen kan läsa)
    "mini": ("NeoQuasar/Kronos-mini", "NeoQuasar/Kronos-Tokenizer-2k", 2048),
    "small": ("NeoQuasar/Kronos-small", "NeoQuasar/Kronos-Tokenizer-base", 512),
    "base": ("NeoQuasar/Kronos-base", "NeoQuasar/Kronos-Tokenizer-base", 512),
}


def hamta_data(ticker: str, minst: int) -> pd.DataFrame:
    """Hämtar dagliga kurser från Yahoo Finance."""
    df = yf.download(ticker, period="5y", interval="1d", auto_adjust=False, progress=False)
    if df is None or df.empty:
        sys.exit(f"Hittade inga kurser för '{ticker}'. Kontrollera tickern, till exempel AAPL eller TSLA.")
    if isinstance(df.columns, pd.MultiIndex):  # nyare yfinance ger dubbla kolumnnamn
        df.columns = df.columns.get_level_values(0)
    df = df.rename(columns=str.lower)[["open", "high", "low", "close", "volume"]].dropna()
    df["amount"] = df["close"] * df["volume"]  # ungefärlig omsättning
    if len(df) < minst:
        sys.exit(f"Bara {len(df)} dagar kurser finns för {ticker}, men {minst} behövs. Prova en annan aktie.")
    return df


def main() -> None:
    ap = argparse.ArgumentParser(description="Kronos-prognos för en aktie")
    ap.add_argument("ticker", nargs="?", default="AAPL", help="aktiens ticker, till exempel AAPL")
    ap.add_argument("--model", choices=MODELS, default="base", help="mini, small eller base")
    ap.add_argument("--days", type=int, default=20, help="hur många handelsdagar framåt (standard 20)")
    ap.add_argument("--paths", type=int, default=30, help="antal banor (fler = långsammare, standard 30)")
    ap.add_argument("--lookback", type=int, default=400, help="hur många dagar bakåt modellen läser")
    ap.add_argument("--seed", type=int, default=None, help="fast slumptal för att få samma svar igen")
    a = ap.parse_args()

    modell_namn, tok_namn, max_ctx = MODELS[a.model]
    lookback = min(a.lookback, max_ctx)
    if a.days < 1 or a.paths < 1:
        sys.exit("--days och --paths måste vara minst 1.")
    if a.seed is not None:
        torch.manual_seed(a.seed)
        np.random.seed(a.seed)

    print(f"Hämtar kurser för {a.ticker} ...")
    df = hamta_data(a.ticker.upper(), lookback)
    hist = df.iloc[-lookback:]
    x_df = hist[["open", "high", "low", "close", "volume", "amount"]].reset_index(drop=True)
    x_ts = pd.Series(pd.to_datetime(hist.index)).reset_index(drop=True)
    # Framtida dagar = vardagar efter sista kursdagen (helgdagar tas inte med)
    y_ts = pd.Series(pd.bdate_range(x_ts.iloc[-1] + pd.Timedelta(days=1), periods=a.days))

    print(f"Laddar Kronos-{a.model} (första gången laddas modellen ner) ...")
    tokenizer = KronosTokenizer.from_pretrained(tok_namn)
    model = Kronos.from_pretrained(modell_namn)
    predictor = KronosPredictor(model, tokenizer, max_context=max_ctx)
    print(f"Kör på: {predictor.device}")

    banor = []
    for i in range(a.paths):
        # En bana per anrop. sample_count>1 skulle ge medelvärdet av banorna, inte banorna själva.
        pred = predictor.predict(
            df=x_df, x_timestamp=x_ts, y_timestamp=y_ts, pred_len=a.days,
            T=1.0, top_p=0.9, sample_count=1, verbose=False,
        )
        banor.append(pred["close"].to_numpy(dtype=float))
        print(f"  bana {i + 1}/{a.paths}", end="\r", flush=True)
    print()
    banor = np.vstack(banor)

    sista = float(x_df["close"].iloc[-1])
    slut = banor[:, -1]
    p10, p50, p90 = np.percentile(slut, [10, 50, 90])
    over = float((slut > sista).mean() * 100)
    print(f"\n{a.ticker.upper()} stängde senast på {sista:.2f}.")
    print(f"Efter {a.days} handelsdagar, bland {a.paths} banor:")
    print(f"  mitten (median): {p50:.2f}  ({(p50 / sista - 1) * 100:+.1f} %)")
    print(f"  lågt (10 %):     {p10:.2f}  ({(p10 / sista - 1) * 100:+.1f} %)")
    print(f"  högt (90 %):     {p90:.2f}  ({(p90 / sista - 1) * 100:+.1f} %)")
    print(f"  {over:.0f} % av banorna slutar över dagens kurs.")
    print("Kom ihåg: det här är en gissning från en AI-modell, inget köptips.")

    fig, ax = plt.subplots(figsize=(11, 5.5))
    visa = min(120, len(x_ts))
    ax.plot(x_ts.iloc[-visa:], x_df["close"].iloc[-visa:], color="black", lw=1.6, label="Verklig kurs")
    for b in banor:
        ax.plot(y_ts, b, color="#e0409a", alpha=0.12, lw=1)
    ax.fill_between(y_ts, np.percentile(banor, 10, axis=0), np.percentile(banor, 90, axis=0),
                    color="#e0409a", alpha=0.18, label="10–90 % av banorna")
    ax.plot(y_ts, np.median(banor, axis=0), color="#a01868", lw=2, label="Median")
    ax.set_title(f"{a.ticker.upper()}: {a.paths} möjliga banor, Kronos-{a.model}")
    ax.set_ylabel("Stängningskurs")
    ax.legend(loc="upper left")
    ax.grid(alpha=0.2)
    fig.autofmt_xdate()
    fig.tight_layout()
    fil = f"kronos_{a.ticker.upper()}_{a.model}.png"
    fig.savefig(fil, dpi=150)
    print(f"Bilden är sparad som {fil}")
    try:
        plt.show()
    except Exception:
        pass


if __name__ == "__main__":
    main()
