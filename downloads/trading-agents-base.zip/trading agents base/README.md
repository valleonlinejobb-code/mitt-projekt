# Trading Agents Base

Allt på ett ställe: de 11 Day Trader-skillsen och Kronos-base.
Det här är experiment och inte finansiell rådgivning. Använd bara pappershhandel.

## Vad som finns i mappen
| Mapp eller fil | Innehåll |
|---|---|
| `.claude/skills/` | De 11 trader-skillsen. Claude Code hittar dem när du startar `claude` i den här mappen. |
| `kronos/` | Kronos (källkod) och `run_kronos.py` som kör en prognos och ritar banorna. |
| `models/` | Kronos-base och dess tokenizer. Fylls när du kör `setup.bat`. |
| `trader/` | Skillsens arbetsfiler. Se `config.json.example`. |
| `output/` | Bilderna som Kronos ritar. |
| `docs/` | Day Trader-skillsens egen README och licens. |
| `setup.bat`, `setup.py` | Installerar allt. |
| `run.bat` | Kör Kronos på en aktie. |

## Så kommer du igång (Windows)
1. Installera **Python 3.12** från python.org. Kryssa i **Add python.exe to PATH**.
2. Packa upp zip-filen. Du behöver cirka 2–4 GB ledigt utrymme, mest för PyTorch.
3. Dubbelklicka på **`setup.bat`**. Det skapar en egen Python-miljö, installerar allt och laddar ner Kronos-base (några hundra MB). Det kan ta 5–15 minuter.
4. Öppna **Kommandotolken** i mappen och kör:
   ```
   run.bat AAPL
   run.bat TSLA --model base --days 20 --paths 50
   ```
   Bilden sparas i mappen `output`.

**Använd NVIDIA-grafikkort:** gå till pytorch.org, välj Windows, Pip och din CUDA-version, och kopiera adressen efter `--index-url`. Kör sedan:
`setup.bat --torch-index ADRESSEN`

**Om setup.bat inte fungerar,** kör detta manuellt i Kommandotolken i mappen:
```
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -r kronos\requirements.txt yfinance
set HF_HOME=%CD%\models
.venv\Scripts\python -c "from huggingface_hub import snapshot_download as d; d('NeoQuasar/Kronos-Tokenizer-base'); d('NeoQuasar/Kronos-base')"
```

## Använda skillsen
1. Installera Claude Code (se code.claude.com) och starta `claude` i den här mappen.
2. Skriv till exempel: *"scanna marknaden efter setups"* eller *"kör time machine på TSLA"*.
3. Skillsen som hämtar SEC-data (`trader-news`, `trader-analyst`) vill veta ditt namn och din e-post. Kopiera `trader/config.json.example` till `trader/config.json` och skriv in dem själv.

## Bra att veta
- **Kronos** gissar utifrån gamla kurser. Banorna visar osäkerhet, inte vad som kommer hända.
- **`trader-broker`** förbereder bara orderförslag och kräver tre godkännanden. Håll `"paper": true`.
- **Ej testat på riktigt:** skriptet och modellen har inte körts mot riktiga Kronos-modellfiler, och `.bat`-filerna har inte testats på Windows.
- **Licenser:** Kronos och Day Trader är MIT-licensierade, och licenserna ligger i `kronos/LICENSE` och `docs/day-trader-skill/LICENSE`.
