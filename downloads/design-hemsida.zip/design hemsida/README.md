# Design hemsida

Samlingsplats för alla design-skills. Starta Claude Code i den här mappen så hittar den dem automatiskt (de ligger i `.claude/skills/`).

## Vad som finns
| Skill | Vad den gör | När du använder den |
|---|---|---|
| `/hallmark` | Bygger webbplatser och nya sidor som ser designade ut, inte genererade | Ny sida eller ny hemsida. På en befintlig design bara om du skriver namnet, till exempel `/hallmark redesign SÖKVÄG` |
| `/impeccable` | Designar, gör om, granskar, putsar och animerar ett gränssnitt | Förbättra något som redan finns: dashboards, appar, komponenter, designsystem (DESIGN.md) |
| `/frontend-design` | Riktlinjer för tydlig visuell riktning: typografi, färg och val som inte ser mallade ut | Som stöd när du bygger eller formar om ett gränssnitt |
| `/ui-ux-pro-max` | Bibliotek med designstilar, färgpaletter, typsnittspar och UX-regler för många ramverk | Välja stil, palett och typsnitt, eller granska UX och tillgänglighet |
| `/design` | Varumärke, logotyper, banners, ikoner, presentationer och sociala bilder | Allt kring identitet och grafik |
| `/ui-styling` | Färdiga komponenter med shadcn/ui och Tailwind CSS, mörkt läge | Bygga själva gränssnittet i kod |
| `/diagram-design` | Över 45 sorters diagram: flödesscheman, tidslinjer, organisationsscheman m.fl. | Förklara något med en snygg bild |
| `/design-system`, `/brand`, `/banner-design`, `/slides` | Syskonskills som `/design` använder: tokens och komponentregler, varumärkesröst, banners, presentationer | Fungerar på egen hand, men måste ligga kvar bredvid `/design` |

`/anthropic-skills:impeccable` är samma skill som `/impeccable`, den som du laddade upp på ditt konto, så den finns bara med en gång.

## Så använder du dem
1. Öppna mappen i Claude Code (`claude` i Kommandotolken i mappen).
2. Skriv till exempel `/hallmark bygg en startsida för min butik`, eller `/impeccable granska min startsida`.
3. Nya sidor: börja med `/hallmark`. Befintliga sidor: `/impeccable`.

## Ingår inte
- **`built-in-browser`** (`/anthropic-skills:built-in-browser`). Den är proprietär och licensen förbjuder att kopiera den ut ur tjänsten. Den ligger redan på ditt konto och fungerar bara i Claude-appen på datorn.

## Bra att veta
- **Hallmark:** beskrivningen är omskriven (`<path>` blev `PATH`) så att filen går att ladda upp på claude.ai. Inget annat är ändrat.
- **Diagram Design:** mörka och helsidesvarianter av exemplen är borttagna för att hålla sig under gränsen på 200 filer. En exempelbild per diagramtyp finns kvar.
- **Testfiler** (`scripts/tests`) är utelämnade.
- **`/design`:** enligt beskrivningen använder logotyp- och ikonfunktionerna externa AI-tjänster och behöver egna nycklar. Det är inte testat.
- **Inte körda:** jag har kontrollerat att filerna är kompletta och att syskonskripten finns, men inte kört skillsen.
- **Licenser:** MIT (Hallmark, Diagram Design, UI/UX Pro Max) och Apache 2.0 (Impeccable, Frontend Design). Texterna ligger i `docs/licenses/`.

## Källor
Hallmark: github.com/Nutlope/hallmark. Impeccable: github.com/pbakaus/impeccable. Diagram Design: github.com/cathrynlavery/diagram-design. UI/UX Pro Max med syskon: github.com/nextlevelbuilder/ui-ux-pro-max-skill. Frontend Design: Anthropic.
