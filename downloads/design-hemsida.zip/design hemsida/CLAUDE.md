# Design hemsida

Samling av design-skills i `.claude/skills/`. Se README.md för listan.

- Nya sidor: använd `/hallmark`. Befintliga sidor: använd `/impeccable`. Hallmark ska inte användas på en befintlig design om inte användaren nämner den.
- `/design` använder syskonskillsen `design-system` och `brand` via relativa sökvägar (`../design-system/scripts/...`). Flytta eller ta aldrig bort dem separat.
- Kör aldrig skript som skickar data till externa tjänster utan att fråga först, och be aldrig om API-nycklar i chatten.
